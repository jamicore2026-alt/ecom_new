import type { Handle } from '@sveltejs/kit'

const REFRESH_COOKIE = 'md.refresh'

const PROTECTED_PREFIXES = [
	'/dashboard',
	'/analytics',
	'/products',
	'/inventory',
	'/orders',
	'/customers',
	'/discounts',
	'/reviews',
	'/settings'
]

export const handle: Handle = async ({ event, resolve }) => {
	const { pathname } = event.url
	const hasSession = event.cookies.get(REFRESH_COOKIE) !== undefined
	const isProtected = PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`))

	const withSecurityHeaders = (response: Response) => {
		response.headers.set('X-Frame-Options', 'DENY')
		response.headers.set('X-Content-Type-Options', 'nosniff')
		response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
		if (process.env.NODE_ENV === 'production') {
			response.headers.set('Strict-Transport-Security', 'max-age=63072000; includeSubDomains')
		}
		if (!response.headers.has('Content-Security-Policy')) {
			response.headers.set('Content-Security-Policy', "default-src 'self'; frame-ancestors 'none'")
		}
		return response
	}

	if (isProtected && !hasSession) {
		return withSecurityHeaders(Response.redirect(new URL('/login', event.url), 302))
	}
	if (pathname === '/login' && hasSession) {
		return withSecurityHeaders(Response.redirect(new URL('/dashboard', event.url), 302))
	}

	return withSecurityHeaders(await resolve(event))
}
