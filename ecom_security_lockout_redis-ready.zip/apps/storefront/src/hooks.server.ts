import type { Handle } from '@sveltejs/kit'

export const handle: Handle = async ({ event, resolve }) => {
	const response = await resolve(event)
	response.headers.set('X-Frame-Options', 'DENY')
	response.headers.set('X-Content-Type-Options', 'nosniff')
	response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
	if (process.env.NODE_ENV === 'production') {
		response.headers.set('Strict-Transport-Security', 'max-age=63072000; includeSubDomains')
	}
	response.headers.set('Content-Security-Policy', response.headers.get('Content-Security-Policy') ?? "default-src 'self'; frame-ancestors 'none'")
	return response
}
