-- Prevent concurrent requests with the same merchant-scoped idempotency key
-- from creating multiple refund reservations / external refund attempts.
CREATE UNIQUE INDEX "refunds_merchant_idempotency_unique_idx"
ON "refunds" USING btree ("merchant_id", "idempotency_key");
